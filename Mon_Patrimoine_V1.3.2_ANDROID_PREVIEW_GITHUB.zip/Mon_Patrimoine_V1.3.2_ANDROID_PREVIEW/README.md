# Mon Patrimoine V1.3.2 — aperçu corrigé

Cette version de test est indépendante. Elle ne remplace pas la V24 contrôlée.

## Corrections incluses
- **Filtre du dashboard rétabli** : Tous les biens, Nom propre, SCI, SARL de famille, Autre société et Autre détention. Les indicateurs du dashboard sont recalculés selon la sélection.
- La ventilation personnelle/détenteur n'est pas réaffichée sur le dashboard. La vue « Tous les biens » consolide aussi les actifs financiers et autres dettes ; une vue filtrée par structure n'ajoute pas ces éléments globaux non affectés à un bien.
- Démarrage vierge et stockage indépendant des anciennes versions de test.
- Réinitialisation qui efface les données et le cache marché.
- Actualisation automatique des estimations à l'ouverture activée par défaut : seules les estimations absentes ou âgées de plus de 7 jours sont relancées. L'utilisateur peut désactiver cette option dans « Marché immobilier ».
- La recherche marché n'envoie que l'adresse, la surface et le type aux services publics requis. Les données de crédit, de loyer, de dettes et de patrimoine ne sont pas transmises.
- Export natif Android du JSON et du CSV, sélection de fichier Android pour importer, et prise en charge des URI de contenu pour la lecture.
- Contrôle des sauvegardes JSON et compatibilité avec les sauvegardes JSON brutes antérieures.
- Tests QA automatisés inclus.

## Étape 1 — Vérifier les contrôles automatisés
Depuis la racine du projet :

```bash
node tests/qa_v13.js
```

## Étape 2 — Compiler avec GitHub Actions (recommandé)
1. Télécharger l'archive et la décompresser sur un ordinateur.
2. Ouvrir le dépôt `yoannparot-stack/Mon-Patrimoine-` sur GitHub.
3. Créer une branche de test nommée `test-v1.3.2` à partir de `main`. Ne pas écraser la branche `main` pour ce premier essai.
4. Dans cette branche, téléverser le **contenu** du dossier `Mon_Patrimoine_V1.3.2_ANDROID_PREVIEW` à la racine du dépôt. Vérifier que `.github/workflows/build.yml`, `app/`, `tests/`, `settings.gradle` et `build.gradle` se trouvent bien à la racine (pas enfermés dans un sous-dossier supplémentaire).
5. Valider le commit sur `test-v1.3.2`. Le workflow est configuré pour se lancer automatiquement sur cette branche.
6. Ouvrir l'onglet **Actions**, sélectionner **Build Mon Patrimoine V1.3.2 preview**, puis ouvrir le dernier lancement associé à `test-v1.3.2`. Si aucun lancement n’apparaît, vérifier que le fichier de workflow est bien à `.github/workflows/build.yml` à la racine, puis utiliser **Run workflow** si le bouton est disponible.
7. Attendre le voyant vert. Ouvrir le run terminé, descendre à **Artifacts**, puis télécharger `Mon-Patrimoine-V1.3.2-PREVIEW-APK`. Décompresser l'archive téléchargée pour récupérer `app-debug.apk`.

## Compilation locale (si Android Studio est installé)
Dans un terminal ouvert à la racine du projet :

```bash
node tests/qa_v13.js
gradle :app:assembleDebug --stacktrace
```

L'APK attendu est `app/build/outputs/apk/debug/app-debug.apk`. La commande Gradle locale nécessite Java 17, Gradle 8.13 et un Android SDK compatible ; GitHub Actions configure ces éléments automatiquement.

## Étape 3 — Autoriser l'écriture GitHub pour ChatGPT
Le connecteur GitHub utilisé dans cette session a renvoyé HTTP 403 `Resource not accessible by integration` lors des tentatives d'écriture. Cela ne se corrige pas dans le code de l'application.

1. Dans ChatGPT, ouvrir **Paramètres → Applications** (le libellé peut varier) et sélectionner **GitHub**.
2. Ouvrir la gestion de connexion ou les autorisations, puis déconnecter/reconnecter GitHub si l'option est proposée.
3. Dans la page GitHub qui s'ouvre, vérifier que l'intégration autorise l'accès au dépôt `yoannparot-stack/Mon-Patrimoine-` et les permissions d'écriture nécessaires pour le contenu du dépôt. Si GitHub affiche une gestion d'accès par dépôt, inclure ce dépôt.
4. Revenir dans ChatGPT et vérifier que GitHub apparaît connecté. Demander ensuite de retenter la création de branche/commit.

Si les permissions proposées ne permettent que la lecture, l'utilisateur devra utiliser l'interface GitHub du navigateur ou un administrateur du dépôt devra modifier les droits de l'intégration. Ne partage jamais de mot de passe ni de jeton personnel dans la conversation.

## Étape 4 — Valider sur téléphone : les 7 tests
Après avoir téléchargé le nouvel APK :
1. **Installation** : installer la V1.3.2 d'aperçu à côté de l'ancienne version si Android le permet ; ne pas désinstaller une version qui contient des données à conserver avant d'avoir exporté une sauvegarde.
2. **Biens** : ajouter un logement, le modifier, puis tester sa suppression.
3. **Dashboard / structures** : créer des biens de test en Nom propre, SCI, SARL de famille et Autre société ; changer le filtre et vérifier que les indicateurs suivent la structure choisie, puis revenir à Tous.
4. **Crédits et banque** : associer un crédit à un logement, vérifier la mensualité, le cash-flow et les informations dans l'onglet Banque.
5. **Sauvegarde** : exporter le JSON, réimporter ce fichier et vérifier que le logement revient ; essayer aussi l'export CSV de la synthèse bancaire.
6. **Réinitialisation** : après avoir sauvegardé les données utiles, utiliser « Effacer toutes les données » et vérifier que le portefeuille revient à vide.
7. **Marché immobilier** : tester avec une adresse réelle, une surface et un type de bien ; vérifier le statut, le résultat ou le message d'erreur réseau, puis désactiver/réactiver l'actualisation automatique.

## Limites connues
Les contrôles automatisés ne remplacent pas la compilation réelle, les interactions sur un appareil ni les requêtes réelles aux services de marché. Ne considérer l'APK comme validé qu'après succès de GitHub Actions et des tests sur téléphone.
