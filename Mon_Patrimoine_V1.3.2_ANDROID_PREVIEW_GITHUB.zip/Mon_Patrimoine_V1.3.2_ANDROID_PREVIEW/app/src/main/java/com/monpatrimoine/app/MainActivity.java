package com.monpatrimoine.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_SAVE_FILE = 4101;
    private static final int REQUEST_OPEN_FILE = 4102;
    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private String pendingExportContent;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void saveFile(String content, String filename, String mimeType) {
                runOnUiThread(() -> beginSaveFile(content, filename, mimeType));
            }
        }, "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(url);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                pendingFilePathCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, REQUEST_OPEN_FILE);
                    return true;
                } catch (Exception e) {
                    pendingFilePathCallback = null;
                    Toast.makeText(MainActivity.this, "Ouverture du fichier impossible.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        setContentView(webView, new ViewGroup.LayoutParams(-1, -1));
    }

    private android.webkit.ValueCallback<Uri[]> pendingFilePathCallback;

    private void beginSaveFile(String content, String filename, String mimeType) {
        pendingExportContent = content;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mimeType == null || mimeType.isEmpty() ? "application/octet-stream" : mimeType);
        intent.putExtra(Intent.EXTRA_TITLE, filename == null || filename.isEmpty() ? "mon_patrimoine_export.json" : filename);
        try {
            startActivityForResult(intent, REQUEST_SAVE_FILE);
        } catch (Exception e) {
            pendingExportContent = null;
            reportSaveResult(false, "le sélecteur de fichier n’est pas disponible");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OPEN_FILE) {
            if (pendingFilePathCallback != null) {
                Uri[] results = (resultCode == RESULT_OK && data != null)
                    ? WebChromeClient.FileChooserParams.parseResult(resultCode, data) : null;
                pendingFilePathCallback.onReceiveValue(results);
                pendingFilePathCallback = null;
            }
            return;
        }
        if (requestCode == REQUEST_SAVE_FILE) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                pendingExportContent = null;
                reportSaveResult(false, "enregistrement annulé");
                return;
            }
            Uri uri = data.getData();
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IllegalStateException("destination inaccessible");
                out.write((pendingExportContent == null ? "" : pendingExportContent).getBytes(StandardCharsets.UTF_8));
                out.flush();
                pendingExportContent = null;
                reportSaveResult(true, "");
            } catch (Exception e) {
                pendingExportContent = null;
                reportSaveResult(false, e.getMessage() == null ? "écriture impossible" : e.getMessage());
            }
        }
    }

    private void reportSaveResult(boolean success, String message) {
        if (webView == null) return;
        String quoted = JSONObject.quote(message == null ? "" : message);
        webView.evaluateJavascript("window.onNativeSaveResult && window.onNativeSaveResult(" + success + "," + quoted + ")", null);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
